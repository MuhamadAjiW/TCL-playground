#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

#define TMin INT_MIN
#define TMax INT_MAX

#include "btest.h"
#include "bits.h"

test_rec test_set[] = {
 {"sharuru", (funct_t) sharuru, (funct_t) test_sharuru, 2,
    "~ & | << >>", 3, 1,
  {{TMin, TMax},{TMin,TMax},{TMin,TMax}}},
 {"vampire", (funct_t) vampire, (funct_t) test_vampire, 2,
    "~ & | << >>", 8, 1,
  {{TMin, TMax},{TMin,TMax},{TMin,TMax}}},
 {"kamippoina", (funct_t) kamippoina, (funct_t) test_kamippoina, 1,
    "! + ~ & ^ | << >>", 6, 1,
  {{0, 31},{TMin,TMax},{TMin,TMax}}},
 {"aidoru_shinetai", (funct_t) aidoru_shinetai, (funct_t) test_aidoru_shinetai, 1,
    "~ & | << >>", 15, 2,
  {{TMin, TMax},{TMin,TMax},{TMin,TMax}}},
 {"bitter_choco_decoration", (funct_t) bitter_choco_decoration, (funct_t) test_bitter_choco_decoration, 1,
    "! ~ & ^ | + << >>", 7, 2,
  {{TMin, TMax},{TMin,TMax},{TMin,TMax}}},
 {"ghost_rule", (funct_t) ghost_rule, (funct_t) test_ghost_rule, 1,
    "~ & ^ | + << >>", 20, 2,
  {{TMin, TMax},{TMin,TMax},{TMin,TMax}}},
    {"hibana", (funct_t) hibana, (funct_t) test_hibana, 3,
    "! ~ & | + << >>", 20, 3, {{0,TMax},{0,TMax},{0,TMax}}},
    {"internet_overdose", (funct_t) internet_overdose, (funct_t) test_internet_overdose, 1,
    "! ~ & ^ | + << >>", 60, 3, {{TMin,TMax},{TMin,TMax},{TMin,TMax}}},
    {"haikei_doppelganger", (funct_t) haikei_doppelganger, (funct_t) test_haikei_doppelganger, 1,
    "! ~ & ^ | + << >>", 60, 3, {{TMin,TMax},{TMin,TMax},{TMin,TMax}}},
    {"hatsune_miku_no_gekishou", (funct_t) hatsune_miku_no_gekishou, (funct_t) test_hatsune_miku_no_gekishou, 2,
    "! ~ & ^ | + << >>", 18, 4, {{TMin,TMax},{TMin,TMax},{TMin,TMax}}},
    {"caliburne_story_of_the_legendary_sword", (funct_t) caliburne_story_of_the_legendary_sword, (funct_t) test_caliburne_story_of_the_legendary_sword, 1,
    "& | ! + >>", 18, 4, {{0,TMax},{0,TMax},{0,TMax}}},
 {"oshama_scramble", (funct_t) oshama_scramble, (funct_t) test_oshama_scramble, 1,
    "$", 30, 4,
     {{1, 1},{1,1},{1,1}}},
  {"regulus", (funct_t) regulus, (funct_t) test_regulus, 1,
  "$", 30, 4, {{1,1},{1,1},{1,1}}},
 {"the_flame_seal_135_seconds", (funct_t) the_flame_seal_135_seconds, (funct_t) test_the_flame_seal_135_seconds,1,
    "! ~ & ^ | + << >>", 60, 4,
  {{TMin, TMax},{TMin,TMax},{TMin,TMax}}},
 {"garakuta_doll_play", (funct_t) garakuta_doll_play, (funct_t) test_garakuta_doll_play, 1, "! ~ & ^ | + << >>", 80, 4,
  {{TMin, TMax},{TMin,TMax},{TMin,TMax}}},
 {"worlds_end_loneliness", (funct_t) worlds_end_loneliness, (funct_t) test_worlds_end_loneliness, 2,
    "! ~ & ^ | + << >>", 80, 4,
  {{0, TMax},{0,TMax},{0,TMax}}},
 {"qzkago_requiem", (funct_t) qzkago_requiem, (funct_t) test_qzkago_requiem, 2,
    "~ & | + << >> %%", 30, 4,
  {{0,TMax},{0,TMax},{0,TMax}}},
 {"pandora_paradoxxx", (funct_t) pandora_paradoxxx, (funct_t) test_pandora_paradoxxx, 1,
    "& | ^ ! << >> ~ + *", 20, 4,
  {{TMin, TMax},{TMin,TMax},{TMin,TMax}}},
  {"", NULL, NULL, 0, "", 0, 0,
   {{0, 0},{0,0},{0,0}}}
};
