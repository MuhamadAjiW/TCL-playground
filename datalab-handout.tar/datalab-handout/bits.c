/* Praktikum 1 IF2130 - Organisasi dan Arsitektur Komputer
 *             II2130 - Arsitektur dan Sistem Komputer
 *
 * NAMA  : <isi nama lengkap di sini>
 * NIM   : <isi nim di sini>
 * KELAS : <isi kelas di sini, IF1/IF2/IF3/STI1/STI2/STI3>
 *
 * BACA INSTRUKSI BERIKUT SEBELUM MEMULAI
 *
 * Aturan Coding Soal Integer
 *
 * Ubah statement "return" pada setiap fungsi dengan satu atau
 * lebih baris kode C yang mengimplementasikan fungsi tersebut.
 * Kode harus mengikuti style:
 *
 * int fungsi(arg1, arg2, ...) {
 *     int var1 = Expr1;
 *     ...
 *     int varX = ExprX;
 *
 *     varY = ExprY;
 *     ...
 *     varZ = ExprZ;
 *     return ExprR;
 * }
 *
 * Setiap "Expr" adalah ekspresi HANYA menggunakan:
 * 1. Konstanta integer 0 hingga 255 (0xFF), inklusif. Anda tidak
 *     diperbolehakn untuk menggunakan konstanta besar seperti
 *     0xffffffff kecuali dituliskan pada soal.
 * 2. Argumen fungsi dan variabel lokal (tidak ada variabel global).
 * 3. Operasi integer uner ! ~
 * 4. Operasi integer biner & ^ | + << >>
 *
 * Beberapa soal merestriksi jumlah operator. Setiap "Expr" terdiri
 * dari beberapa operator. Anda tidak dibatasi oleh 1 operator per baris.
 *
 * Anda sangat dilarang untuk:
 * 1. Menggunakan control constructs apapun, seperti if, do, while, for,
 *     switch, dll.
 * 2. Menggunakan macro.
 * 3. Membuat fungsi baru di file ini.
 * 4. Memanggil fungsi lain.
 * 5. Menggunakan operasi lain, seperti &&, ||, -, atau ?:
 * 6. Menggunakan bentuk casting apapun.
 * 7. Menggunakan tipe data selain int. Ini berarti Anda tidak boleh
 *     menggunakan array, struct, atau union.
 *
 * Anda dapat berasumsi mesin Anda:
 * 1. Menggunakan 2s complement, representasi bilangan 32-bit.
 * 2. Mengeksekusi right shift secara aritmetik.
 * 3. Memiliki perilaku unpredictable ketika menggeser integer
 *     lebih dari ukuran word.
 *
 * Aturan Coding Soal Float
 *
 * Untuk soal yang membutuhkan operasi floating-point, style koding lebih
 * lenient. Anda diperbolehkan menggunakan ints dan unsigneds.
 * Anda dapat menggunakan arbitrary integer dan konstanta unsigned.
 *
 * Anda sangat dilarang untuk:
 * 1. Menggunakan macro.
 * 2. Membuat fungsi baru di file ini.
 * 3. Memanggil fungsi lain.
 * 4. Menggunakan bentuk casting apapun.
 * 5. Menggunakan tipe data selain int atau unsigned.
 *     Ini berarti Anda tidak dapat menggunakan array, struct, ataupun union.
 * 6. Menggunakan floating point apapun untuk tipe data, operasi,
 *     atau konstanta.
 *
 * Notes:
 * Setiap fungsi memiliki jumlah operator maximum (! ~ & ^ | + << >>)
 * yang boleh digunakan untuk mengimplementasikan fungsi.
 * NB: '=' tidak dihitung. Anda dapat menggunakan ini sebanyak
 * apapun tanpa penalti.
 */
/*
 * wajib
 * sharuru - Menggabungkan representasi biner dua integer dengan ketentuan:
 *  bit ke-1 sampai ke-4 akan diambil dari bit ke-1 sampai ke-4 x
 *  bit ke-5 sampai ke-8 akan diambil dari bit ke-5 sampai ke-8 y
 *  bit sisanya akan bernilai 0
 * 
 * Contoh:
 *  sharuru(0xFF, 0x00) = 0x0F
 *  sharuru(0x00, 0xFF) = 0xF0
 *  sharuru(0x12, 0xAB) = 0xA2
 *  sharuru(0xF0, 0x12) = 0x10
 *
 * Legal ops    : ~ & | << >>
 * Max ops      : 3
 * Rating       : 1
 */
int sharuru(int x, int y){
  return 2;
}
/*
 * wajib
 * vampire - Mengembalikan nilai dengan ketentuan:
 * Jika bit pada posisi yang sama pada kedua bilangan sama, maka bit tersebut akan bernilai 1
 * Jika bit pada posisi yang sama pada kedua bilangan berbeda, maka bit tersebut akan bernilai 0
 * 
 * Contoh:
 *  vampire(0, 0) = -1 karena bit sama semua jadi 0xFFFF_FFFF
 *  vampire(0, 1) = -2 karena bit sama semua kecuali yang terakhir jadi 0xFFFF_FFFE
 *  vampire(0xFFFF0000, 0x0000FFFF) = 0 karena tidak ada bit yang sama
 *  vampire(0x0000000F, 0xFFFFFFF8) = 8 karena 0b1111 XNOR 0b1000 = 0b0111
 * 
 * Legal ops    : ~ & | << >>
 * Max ops      : 8
 * Rating       : 1
 */
int vampire(int x, int y){
  return 2;
}
/*
 * wajib
 * kamippoina - Mengembalikan nilai sigma 0->x 2^x
 *
 * Contoh:
 *  kamippoina(4) = 31
 *  kamippoina(2) = 7
 * 
 * Legal ops    : ! + ~ & ^ | << >> 
 * Max ops      : 6
 * Rating       : 1
 */
int kamippoina(int n){
  return 2;
}
/*

 * wajib

 * aidoru_shinetai - Tukarlah bit ke-1 dan bit ke-4 dari a

 * 

 * Contoh:

 *  aidoru_shinetai(0b1000) = 0b0001

 *  aidoru_shinetai(0b0001) = 0b1000

 *  aidoru_shinetai(0b1010) = 0b0011

 *  aidoru_shinetai(0b0101) = 0b1100

 * 

 * Legal ops    : ~ & | << >>

 * Max ops      : 15

 * Rating       : 2

 */
int aidoru_shinetai(int a){
  return 2;
}
/**

 * wajib

 * bitter_choco_decoration - Mengembalikan nilai x * 23 

 * 

 * Contoh:  

 *  bitter_choco_decoration(1) = 23.

 *  bitter_choco_decoration(23) = 529.

 *  bitter_choco_decoration(-69) = -1587.

 * 

 * Legal ops: ! ~ & ^ | + << >>

 * Max ops: 7

 * Rating: 2

 */
int bitter_choco_decoration(int x){
  return 2;
}
/*
 * wajib
 * ghost_rule - Mengembalikan 1 apabila x merupakan 2^n dan 0 apabila tidak (n >= 0)
 * 
 * Legal ops: ~ & ^ | + << >>
 * Max Ops: 20
 * Rating: 2
*/
int ghost_rule(int n){
  return 2;
}
/*

 * wajib

 * hibana - Mengembalikan nilai tertinggi dari 3 input integer

 *  a, b, c >= 0

 * 

 * Contoh:

 *  hibana(1, 9, 5) = 9

 *  hibana(10, 3, 5) = 10

 * 

 * Legal ops    : ! ~ & | + << >> 

 * Max ops      : 20

 * Rating       : 3

 */
int hibana(int a, int b, int c) {
    return 2;
}
/*

 * wajib

 * internet overdose - Mengembalikan hasil shuffling terhadap bits dari x, dengan ketentuan:

 *  abcd efgh ijkl mnop ABCD EFGH IJKL MNOP -> aAbB cCdD eEfF gGhH iIjJ kKlL mMnN oOpP

 *

 * Contoh:  

 *  internet_overdose(0xFFFF0000) = 0xAAAAAAAA.

 * 

 * Legal ops: ! ~ & ^ | + << >>

 * Max ops: 60

 * Rating: 3

 */
int internet_overdose(int i) {
    return 2;
}
/*

 * wajib

 * haikei doppelganger - Memeriksa apakah setiap word dalam x merupakan huruf dalam representasi ASCII

 * 

 * Contoh:  

 *  haikei_doppelganger(0x62797465) = 1.

 *  haikei_doppelganger(0x6D696B75) = 1.

 *  haikei_doppelganger(0xFF797465) = 0.

 *  haikei_doppelganger(0xFFFFFFFF) = 0

 *   

 * Legal ops: ! ~ & ^ | + << >>

 * Max ops: 60

 * Rating: 3

 */
int haikei_doppelganger(int x) {
    return 2;
}
/* 
 * wajib
 * hatsune miku no gekishou - Mengembalikan hasil penambahan 2 integer, dengan ketentuan:
 *  jika terjadi overflow positif, kembalikan nilai maxint
 *  jika terjadi overflow negatif, kembalikan nilai minint
 * 
 * Contoh:
 *  hatsune_miku_no_gekishou(0x40000000,0x40000000) = 0x7fffffff
 *  hatsune_miku_no_gekishou(0x80000000,0xffffffff) = 0x80000000
 * 
 * Legal ops    : ! ~ & ^ | + << >>
 * Max ops      : 18
 * Rating       : 4
*/
int hatsune_miku_no_gekishou(int x, int y) {
    return 2;
}
/* 

 * wajib

 * caliburne_story_of_the_legendary_sword - Mengembalikan ceil(x * 5/128) dengan ketentuan:

 *  pembagian yang digunakan adalah pembagian real

 *  ceil(x) menghasilkan bilangan bulat terkecil yang lebih besar atau sama dengan x

 * 

 * Contoh:

 * 

 * Legal ops    : Unsigned, & | ! + >>

 * Max Ops      : 18

 * Rating       : 4

*/
unsigned caliburne_story_of_the_legendary_sword(unsigned x) {
    return 2;
}
/**

 * wajib

 * oshama_scramble - Mengembalikan bit-level equivalent dari ekspresi (int) f

 *  argumen f merupakan representasi bit dari bilangan desimal dalam bentuk single-precision floating point

 *  jika nilai float melebihi batasan (termasuk NaN dan infinity), kembalikan 0x80000000u

 * 

 * Contoh:  

 *  oshama_scramble(32.0) = 32

 *  oshama_scramble(-420.69) = -420 

 *  oshama_scramble(0.000026) = 0

 *  oshama_scramble(88888888888) = max int

 * 

 * Legal ops    : semua operasi integer/unsigned termasuk ||, &&. juga if, while

 * Max ops      : 30

 * Rating       : 4

 */
int oshama_scramble(unsigned uf) {
  return 2;
}
/*

 * bonus

 * regulus - Menghitung 2*f untuk suatu bilangan floating point f

 *  argumen f dan hasil merupakan representasi bit dari bilangan desimal dalam bentuk single-precision floating point

 *  jika f NaN, kembalikan f.

 * 

 * Legal ops    : Semua operasi integer/unsigned termasuk ||, &&. juga if, while; konstanta besar

 * Max ops      : 30

 * Rating       : 4

*/
unsigned regulus(unsigned uf) {
  return 2;
}
/*
 * bonus
 * the_flame_seal_135_seconds - mengembalikan jumlah bit 1 konsekutif pada x, dari sebelah kiri (MSB)
 * 
 * Contoh:
 *  the_flame_seal_135_seconds(-1) = 32 
 *  the_flame_seal_135_seconds(0xFFF0F0F0) = 12
 *  
 * Legal ops    : ! ~ & ^ | + << >>
 * Max ops      : 60
 * Rating       : 4
 */
int the_flame_seal_135_seconds(int x) {
  return 2;
}
/*
 * bonus
 * garakuta_doll_play - mengembalikan bit 1 paling signifikan dan paling tidak signifikan, atau 0 jika x == 0
 * 
 * Contoh:
 *  garakuta_doll_play(97) = 0x41
 *  
 * Legal ops    : ! ~ & ^ | + << >>
 * Max ops      : 80
 * Rating       : 4
 */
int garakuta_doll_play(int x) {
    return 2;
}
/* 

 * bonus

 * worlds_end_loneliness - Mengembalikan GCD dari x dan y (x, y >= 0)

 * 

 * Legal ops    : Conditional & looping, ! ~ & ^ | + << >>

 * Max ops      : 80

 * Rating       : 4

*/
int worlds_end_loneliness(int x, int y){
  return 2;
}
/**

 * bonus

 * qzkago_requiem - Menghitung hasil perkalian unsigned int (32 bit) a * b

 *  hasil perkalian dapat menghasilkan nilai yang lebih besar dari 2^32-1 (max unsigned int) 

 *  jika x adalah hasil perkalian a * b,

 *  kembalikan (x % 32) % (x / 32), jika x/32 > 0;

 *  jika tidak kembalikan x % 32

 * 

 *  jika anda menggunakan perulangan, perhatikan jumlah iterasi yang anda gunakan

 * 

 * Legal ops  : Conditional, looping, konstanta besar, unsigned, ~ & | + << >> %

 * Max Ops    : 30

 * Rating     : 4

*/
unsigned qzkago_requiem(unsigned a, unsigned b) {
    return 2;
}
/*

 * s u p e r  b o n u s

 * pandora_paradoxxx - Mengembalikan hasil pembagian kebawah x dengan 196 (x/196)

 * 

 * Contoh:  

 *  pandora_paradoxxx(1000) = 5

 * 

 * Legal ops    : Konstanta besar, unsigned, & | ^ ! << >> ~ + *

 * Max ops      : 20

 * Rating       : 5

 */
int pandora_paradoxxx(int x){
  return 2;
}
